# Digital-Signal-Processor-Design-in-FPGA
##Description
A digital signal processor designed in FPGA in verilog with ps2 keyboard interfacing to take inputs and LCD interfacing to display the result.

Various algorithms of digital signal processing like Fast Fourier Transform and Multiply and Accumulate implemented along with construction of ALU and control unit.

##RTL schematic of top level block
![dsp](https://cloud.githubusercontent.com/assets/20043960/18980342/0c61661a-86f3-11e6-984b-c6bff9d97620.PNG)
